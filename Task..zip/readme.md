Install the dependencies
change username and password in selenium_script.py
run selenium_script.py to fetch trends and store them in mongo url
run app.py backend server and index.html for frontend
click on fetch trends